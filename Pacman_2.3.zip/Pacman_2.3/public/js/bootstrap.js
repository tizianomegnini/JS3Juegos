﻿resizeCanvas();
showMenu();
updateHUD();
updateHsDisplay();
